from django.contrib import admin

# Register your models here.

from .models import *


class BookInfoAdmin(admin.ModelAdmin):
    list_display = ['pk', 'btitle', 'bpub_date']
    list_filter = ['btitle']
    search_fields = ['btitle']
    list_per_page = 10





admin.site.register(BookInfo,BookInfoAdmin)
admin.site.register(HeroInfo)


