from django.shortcuts import render

# Create your views here.
# from django.http import *
# from django.template import RequestContext, loader
from .models import *


def index(request):
    # temp = loader.get_template('booktest/index.html')
    # return HttpResponse(temp.render())
    bookinfos = BookInfo.objects.all()
    context = {'title': 'hello', 'list': bookinfos}

    return render(request, 'booktest/index.html', context)


def detail(request):
    print("-----------------", request)
    # bookInfo = BookInfo.objects.get(pk=id)
    # context = {'info': bookInfo}
    context = {'info': ""}
    return render(request, 'booktest/detail.html', context)
    pass
